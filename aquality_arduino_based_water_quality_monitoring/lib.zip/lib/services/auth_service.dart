import 'package:flutter/foundation.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'firebase_service.dart';

class AuthService {
  // Singleton
  static final AuthService _instance = AuthService._internal();
  factory AuthService() => _instance;
  AuthService._internal();
  static AuthService get instance => _instance;

  final FirebaseAuth _auth = FirebaseAuth.instance;

  final ValueNotifier<bool> isAdmin = ValueNotifier<bool>(false);
  final ValueNotifier<bool> isLoggedIn = ValueNotifier<bool>(false);

  /// The currently signed-in Firebase user (null if not logged in)
  User? get currentUser => _auth.currentUser;

  /// Listen to Firebase Auth state changes automatically
  void listenToAuthChanges() {
    _auth.authStateChanges().listen((User? user) async {
      if (user == null) {
        isLoggedIn.value = false;
        isAdmin.value = false;
      } else {
        isLoggedIn.value = true;
        // Fetch user role from Firestore to determine admin status
        final role = await FirebaseService.instance.getUserRole(user.uid);
        isAdmin.value = role == 'admin' ||
            role == 'fishPondOwner' ||
            role == 'lgu';
      }
    });
  }

  /// Sign in with email and password
  Future<AuthResult> signIn(String email, String password) async {
    try {
      final credential = await _auth.signInWithEmailAndPassword(
        email: email.trim(),
        password: password,
      );
      final user = credential.user;
      if (user == null) return AuthResult.error('Login failed. Try again.');

      final role = await FirebaseService.instance.getUserRole(user.uid);
      isAdmin.value = role == 'admin' ||
          role == 'fishPondOwner' ||
          role == 'lgu';
      isLoggedIn.value = true;

      return AuthResult.success(isAdmin: isAdmin.value);
    } on FirebaseAuthException catch (e) {
      return AuthResult.error(_mapFirebaseError(e.code));
    } catch (e) {
      return AuthResult.error('An unexpected error occurred.');
    }
  }

  /// Register a new account
  Future<AuthResult> signUp({
    required String email,
    required String password,
    required String displayName,
    required String username,
    required String role,
  }) async {
    try {
      final credential = await _auth.createUserWithEmailAndPassword(
        email: email.trim(),
        password: password,
      );
      final user = credential.user;
      if (user == null) return AuthResult.error('Sign up failed. Try again.');

      // Update display name in Firebase Auth
      await user.updateDisplayName(displayName);

      // Save user profile to Firestore
      await FirebaseService.instance.createUserProfile(
        uid: user.uid,
        displayName: displayName,
        email: email.trim(),
        username: username,
        role: role,
      );

      final adminRoles = ['admin', 'fishPondOwner', 'lgu'];
      isAdmin.value = adminRoles.contains(role);
      isLoggedIn.value = true;

      return AuthResult.success(isAdmin: isAdmin.value);
    } on FirebaseAuthException catch (e) {
      return AuthResult.error(_mapFirebaseError(e.code));
    } catch (e) {
      return AuthResult.error('An unexpected error occurred.');
    }
  }

  /// Sign out
  Future<void> logout() async {
    await _auth.signOut();
    isAdmin.value = false;
    isLoggedIn.value = false;
  }

  /// Password reset email
  Future<AuthResult> sendPasswordReset(String email) async {
    try {
      await _auth.sendPasswordResetEmail(email: email.trim());
      return AuthResult.success(isAdmin: false);
    } on FirebaseAuthException catch (e) {
      return AuthResult.error(_mapFirebaseError(e.code));
    }
  }

  String _mapFirebaseError(String code) {
    switch (code) {
      case 'user-not-found':
        return 'No account found with this email.';
      case 'wrong-password':
        return 'Incorrect password.';
      case 'invalid-email':
        return 'Please enter a valid email address.';
      case 'email-already-in-use':
        return 'An account with this email already exists.';
      case 'weak-password':
        return 'Password must be at least 6 characters.';
      case 'too-many-requests':
        return 'Too many failed attempts. Please try again later.';
      case 'network-request-failed':
        return 'Network error. Check your connection.';
      case 'invalid-credential':
        return 'Invalid email or password.';
      default:
        return 'Authentication error. Please try again.';
    }
  }
}

class AuthResult {
  final bool success;
  final bool isAdmin;
  final String? errorMessage;

  AuthResult._({
    required this.success,
    required this.isAdmin,
    this.errorMessage,
  });

  factory AuthResult.success({required bool isAdmin}) =>
      AuthResult._(success: true, isAdmin: isAdmin);

  factory AuthResult.error(String message) =>
      AuthResult._(success: false, isAdmin: false, errorMessage: message);
}
